package com.registration_application.controller;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.registration_application.model.DAOService;
import com.registration_application.model.DAOServiceImpl;

@WebServlet("/AllReg")
public class ReadRegistrationcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ReadRegistrationcontroller() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DAOService service = new DAOServiceImpl();
		service.connectdb();
		ResultSet rs=service.getAllRegistrations();
		request.setAttribute("res", rs);
		RequestDispatcher rd=request.getRequestDispatcher("/WEB-INF/view/showRegistration.jsp");
		rd.forward(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
