package com.registration_application.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DAOServiceImpl implements DAOService {
	private Connection con;
	private Statement stmt;
	@Override
	public void connectdb() {
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/registration_app","root", "Akash@123");
		stmt=con.createStatement();
		}catch(Exception e) {
		e.printStackTrace();
	}
	}

	@Override
	public boolean verifyLogin(String username, String password) {
		try {
			ResultSet rs=stmt.executeQuery("select * from login where email='"+username+"'and password='"+password+"'");
			return rs.next();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public void saveRegistration(String name, String city, String email, String number) {
		try {
			stmt.executeUpdate("insert into registration values('"+name+"','"+city+"','"+email+"','"+number+"')");
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public boolean exitsEmail(String email) {
		try {
			ResultSet rs=stmt.executeQuery("select * from registration where email='"+email+"'");
			return rs.next();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean exitsNumber(String mobile) {
		try {
			ResultSet rs=stmt.executeQuery("select * from registration where mobile='"+mobile+"'");
			return rs.next();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public ResultSet getAllRegistrations() {
		try {
			ResultSet rs=stmt.executeQuery("select * from registration");
			return rs;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void deleteByEmail(String email) {
		try {
			stmt.executeUpdate("delete  from registration where email='"+email+"'");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void updateRegistration(String email, String mobile) {
		try {
			stmt.executeUpdate("update registration set mobile='"+mobile+"'where email='"+email+"'");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

		
	}

	

