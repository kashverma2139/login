package com.registration_application.model;

import java.sql.ResultSet;

public interface DAOService {
	public void connectdb();
 public boolean verifyLogin(String username,String password);
 public void  saveRegistration(String name,String city,String email,String number);
 public boolean exitsEmail(String email);
 public boolean exitsNumber(String mobile);
public ResultSet getAllRegistrations();
public void deleteByEmail(String email);
public void updateRegistration(String email, String mobile);
 
}
